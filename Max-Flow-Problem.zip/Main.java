import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

class Main {

	static class Graph {
		int vertices;
		int[][] graph;

		public Graph(int vertices, int[][] graph) {
			this.vertices = vertices;
			this.graph = graph;
		}

		public int maxFlow(int source, int sink) {
			int[][] residual = new int[vertices][vertices];

			for (int i = 0; i < vertices; i++) {
				for (int j = 0; j < vertices; j++) {
					residual[i][j] = graph[i][j];
				}
			}

			int[] parents = new int[vertices];

			int max = 0;

			while (pathExists(residual, source, sink, parents)) {
				int capacity = Integer.MAX_VALUE;

				int t = sink;

				while (t != source) {
					int s = parents[t];
					capacity = Math.min(capacity, residual[s][t]);
					t = s;
				}

				t = sink;
				while (t != source) {
					int s = parents[t];
					residual[s][t] -= capacity;
					residual[t][s] += capacity;
					t = s;
				}

				max += capacity;
			}
			return max;
		}

		public boolean pathExists(int[][] residual, int source, int dest, int[] parents) {
			boolean found = false;

			boolean[] visited = new boolean[vertices];

			Queue<Integer> queue = new LinkedList<>();

			queue.add(source);
			parents[source] = -1;
			visited[source] = true;

			while (!queue.isEmpty()) {
				int poll = queue.poll();

				for (int i = 0; i < vertices; i++) {
					if (!visited[i] && residual[poll][i] > 0) {
						queue.add(i);
						parents[i] = poll;
						visited[i] = true;
					}
				}
			}

			found = visited[dest];
			return found;
		}

	}

	public static void main(String[] args) {
		int[] entrances = { 0 };
		int[] exits = { 3 };
		int[][] path = { {0, 7, 0, 0}, {0, 0, 6, 0}, {0, 0, 0, 8}, {9, 0, 0, 0}};

		ArrayList<ArrayList<Integer>> pathList = new ArrayList<ArrayList<Integer>>();

		ArrayList<Integer> enPlace = new ArrayList<Integer>();

		enPlace.add(0);

		for (int i = 0; i < path.length; i++) {
			boolean entrance = false;
			for (int j = 0; j < entrances.length; j++) {
				if (i == entrances[j]) {
					entrance = true;
				}
			}

			if (entrance) {
				enPlace.add(Integer.MAX_VALUE);
			} else {
				enPlace.add(0);
			}
		}

		pathList.add(enPlace);

		for (int i = 0; i < path.length; i++) {
			int[] row = path[i];
			ArrayList<Integer> rowList = new ArrayList<Integer>();
			rowList.add(0);
			for (int j = 0; j < row.length; j++) {
				rowList.add(row[j]);
			}

			boolean isExit = false;

			for (int j = 0; j < exits.length; j++) {
				if (i == exits[j]) {
					isExit = true;
					break;
				}
			}

			if (isExit) {
				rowList.add(Integer.MAX_VALUE);
			} else {
				rowList.add(0);
			}
			pathList.add(rowList);
		}

		ArrayList<Integer> exPlace = new ArrayList<Integer>();

		exPlace.add(0);

		for (int i = 0; i < path.length; i++) {
			exPlace.add(0);
		}

		exPlace.add(0);

		pathList.add(exPlace);
		pathList.get(0).add(0);

		for (ArrayList<Integer> row : pathList) {
			System.out.println(row);
		}

		int[][] paths = new int[pathList.size()][pathList.size()];

		for (int i = 0; i < pathList.size(); i++) {
			for (int j = 0; j < pathList.get(i).size(); j++) {
				paths[i][j] = pathList.get(i).get(j);
			}
		}

		int v = paths.length;

		Graph network = new Graph(v, paths);

		int source = 0;
		int sink = paths.length - 1;

		int flow = network.maxFlow(source, sink);
		System.out.println(flow);
	}
}